document.addEventListener("DOMContentLoaded", function() {
    if (document.getElementById("product-list")) {
        fetch("/api/products")
            .then(res => res.json())
            .then(data => {
                let productsHTML = "";
                data.forEach(product => {
                    productsHTML += `
                        <div class="product-card">
                            <img src="${product.image}" alt="${product.name}">
                            <h3>${product.name}</h3>
                            <p>${product.description}</p>
                            <p><strong>${product.price.toLocaleString("es-CO")} COP</strong></p>
                            <button onclick="addToCart(${product.id})">Añadir al carrito</button>
                        </div>
                    `;
                });
                document.getElementById("product-list").innerHTML = productsHTML;
            });
    }

    if (document.getElementById("cart-items")) {
        renderCart();
    }
});

function addToCart(id) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(id);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Producto añadido al carrito");
}

function renderCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    fetch("/api/products")
        .then(res => res.json())
        .then(products => {
            let cartHTML = "";
            cart.forEach(id => {
                let product = products.find(p => p.id === id);
                cartHTML += `
                    <div>
                        <h3>${product.name}</h3>
                        <p>${product.price.toLocaleString("es-CO")} COP</p>
                    </div>
                `;
            });
            document.getElementById("cart-items").innerHTML = cartHTML;
        });
}

function checkout() {
    window.location.href = "checkout.html";
}