const express = require("express");
const app = express();

app.use(express.static("public"));

const products = [
    { 
        id: 1, 
        name: "MacBook Pro 14”", 
        description: "Potente laptop con chip M2 Pro y pantalla Retina.",
        price: 10500000, 
        image: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/refurb-macbook-pro-14-2021-silver?wid=2000&hei=2000&fmt=jpeg&qlt=80&.v=1638575927000"
    },
    { 
        id: 2, 
        name: "iPhone 14 Pro Max", 
        description: "Celular de última generación con Dynamic Island.",
        price: 6200000, 
        image: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-14-pro-finish-select-202209-6-1inch-deeppurple?wid=470&hei=556&fmt=png-alpha&.v=1663613989446"
    },
    { 
        id: 3, 
        name: "Samsung Galaxy S23 Ultra", 
        description: "Cámara de 200MP y batería de larga duración.",
        price: 5800000, 
        image: "https://images.samsung.com/is/image/samsung/p6pim/co/2302/gallery/co-galaxy-s23-s918-sm-s918bzgacon-thumb-534328969?$344_344_PNG$"
    }
];

app.get("/api/products", (req, res) => {
    res.json(products);
});

app.listen(3000, () => {
    console.log("Servidor corriendo en http://localhost:3000");
});